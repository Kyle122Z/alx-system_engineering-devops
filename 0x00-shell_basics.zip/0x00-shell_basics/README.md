Non-empty readme file
